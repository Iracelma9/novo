package IP.sintaxy.Controler;

import IP.sintaxy.Model.Livro;
import IP.sintaxy.Service.LivroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/livro")
public class LivroController {

    @Autowired
    private LivroService livroService;

    @PostMapping("/criar")
    @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
    public Livro criarLivro(@RequestBody Livro livro) {
        return livroService.criarLivro(livro);
    }

    @GetMapping("/listar")
    public List<Livro> listarLivros() {
        return livroService.listarLivro();
    }


}
