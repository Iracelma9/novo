package IP.sintaxy.Controler;

public @interface Valid {
}
