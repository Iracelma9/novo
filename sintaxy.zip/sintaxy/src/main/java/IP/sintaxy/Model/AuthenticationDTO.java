package IP.sintaxy.Model;

public record AuthenticationDTO(String login, String password) {
}
