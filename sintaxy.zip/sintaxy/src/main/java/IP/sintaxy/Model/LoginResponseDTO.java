package IP.sintaxy.Model;

public record LoginResponseDTO(String token) {
}
