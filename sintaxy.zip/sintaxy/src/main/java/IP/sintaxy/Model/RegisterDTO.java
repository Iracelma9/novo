package IP.sintaxy.Model;

public record RegisterDTO(String login, String password,Role role) {
}
