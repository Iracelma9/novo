package IP.sintaxy.Model;

public enum Role {
    ADMIN("ROLE_admin"),
    USER("ROLE_user");

    private String role;

    Role(String role){
        this.role=role;
    }
    public  String getRole(){
        return role;
    }
}
