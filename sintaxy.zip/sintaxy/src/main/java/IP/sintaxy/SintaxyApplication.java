package IP.sintaxy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SintaxyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SintaxyApplication.class, args);
	}

}
