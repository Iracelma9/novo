package IP.sintaxy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SintaxyApplicationTests {

	@Test
	void contextLoads() {
	}

}
